# uwd > 2025-12-16 3:00pm
https://universe.roboflow.com/surender/uwd

Provided by a Roboflow user
License: CC BY 4.0

